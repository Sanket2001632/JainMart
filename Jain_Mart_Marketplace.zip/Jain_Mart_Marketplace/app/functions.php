<?php
declare(strict_types=1);

function e(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function cfg(string $key, mixed $default = null): mixed {
    $parts = explode('.', $key); $value = $GLOBALS['config'] ?? [];
    foreach ($parts as $part) {
        if (!is_array($value) || !array_key_exists($part, $value)) return $default;
        $value = $value[$part];
    }
    return $value;
}
function url(string $path = ''): string {
    return rtrim((string)cfg('base_url', ''), '/') . '/' . ltrim($path, '/');
}
function redirect(string $path): never {
    header('Location: ' . url($path), true, 302); exit;
}
function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
function verify_csrf(): void {
    $sent = (string)($_POST['_csrf'] ?? '');
    if ($sent === '' || !hash_equals((string)($_SESSION['_csrf'] ?? ''), $sent)) {
        http_response_code(419); exit('Session token expired. Please go back and retry.');
    }
}
function icon(string $name, bool $ariaHidden = true): string {
    static $paths = [
        'bag' => '<path d="M6 8h12l1 12H5L6 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
        'search' => '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
        'user' => '<circle cx="12" cy="8" r="4"/><path d="M5 20c1.5-3.5 4-5 7-5s5.5 1.5 7 5"/>',
        'cart' => '<path d="M4 6h2l2.4 10.2A2 2 0 0 0 10.3 18h6.9a2 2 0 0 0 2-1.6L20.5 9H7"/><circle cx="10.5" cy="21" r="1.3"/><circle cx="17.5" cy="21" r="1.3"/>',
        'truck' => '<path d="M3 7h11v9H3z"/><path d="M14 10h4l3 3v3h-7z"/><circle cx="7" cy="18.5" r="1.8"/><circle cx="17" cy="18.5" r="1.8"/>',
        'shield' => '<path d="M12 3l7 3v5c0 5-3.5 8.5-7 10-3.5-1.5-7-5-7-10V6l7-3Z"/><path d="m9 12 2 2 4-4"/>',
        'refresh' => '<path d="M4 12a8 8 0 0 1 14-5.3L20 8"/><path d="M20 4v4h-4"/><path d="M20 12a8 8 0 0 1-14 5.3L4 16"/><path d="M4 20v-4h4"/>',
        'support' => '<path d="M4 13a8 8 0 0 1 16 0"/><path d="M4 13v4a2 2 0 0 0 2 2h1v-6H6a2 2 0 0 0-2 2Zm16 0v4a2 2 0 0 1-2 2h-1v-6h1a2 2 0 0 1 2 2Z"/><path d="M17 19c0 1.5-1.8 2.5-4 2.5"/>',
        'arrow-right' => '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
        'menu' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
        'check' => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
        'check-circle' => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 5-5.5"/>',
        'alert' => '<path d="M12 4.5 2.8 20h18.4L12 4.5Z"/><path d="M12 10v4.5"/><circle cx="12" cy="17.4" r=".8" fill="currentColor" stroke="none"/>',
        'info' => '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5"/><circle cx="12" cy="7.8" r=".8" fill="currentColor" stroke="none"/>',
        'package' => '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="M12 12l8-4.5M12 12v9M12 12 4 7.5"/>',
        'boxes' => '<path d="M4 9.5 8.5 7l4.5 2.5L8.5 12 4 9.5Z"/><path d="m13 14.5 4.5-2.5 4.5 2.5-4.5 2.5-4.5-2.5Z"/><path d="M13 9.5 17.5 7 22 9.5 17.5 12 13 9.5Z"/>',
        'tags' => '<path d="M4 12.5V5a1 1 0 0 1 1-1h7.5L21 12.5 12.5 21 4 12.5Z"/><circle cx="8.5" cy="8.5" r="1.4"/>',
        'clipboard' => '<path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4"/>',
        'chart' => '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
        'pin' => '<path d="M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11Z"/><circle cx="12" cy="10" r="2.6"/>',
        'lock' => '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        'globe' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.8 3 2.8 15 0 18-2.8-3-2.8-15 0-18Z"/>',
    ];
    $body = $paths[$name] ?? $paths['check'];
    $hide = $ariaHidden ? ' aria-hidden="true" focusable="false"' : '';
    return '<svg class="icon" viewBox="0 0 24 24"' . $hide . '>' . $body . '</svg>';
}
function status_badge(?string $status): string {
    $s = trim((string)($status ?? ''));
    if ($s === '') return '';
    $label = ucwords(str_replace('_', ' ', $s));
    return '<span class="badge status-' . e($s) . '">' . e($label) . '</span>';
}
function stock_badge(int $stock): string {
    return $stock > 0
        ? '<span class="badge in-stock">In stock</span>'
        : '<span class="badge out-stock">Out of stock</span>';
}
function condition_badge(?string $label): string {
    $text = ucwords(str_replace('_', ' ', (string)($label ?: 'condition_not_specified')));
    return '<span class="badge condition">' . e($text) . '</span>';
}
function flash(string $type, string $message): void {
    $_SESSION['_flash'][] = ['type'=>$type, 'message'=>$message];
}
function render_flashes(): void {
    $items = $_SESSION['_flash'] ?? []; unset($_SESSION['_flash']);
    foreach ($items as $item) {
        $icon = $item['type'] === 'success' ? icon('check-circle') : icon('alert');
        echo '<div class="flash '.e($item['type']).'" role="'.($item['type']==='success'?'status':'alert').'">'.$icon.'<span>'.e($item['message']).'</span></div>';
    }
}
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function is_admin(): bool { return (current_user()['role'] ?? '') === 'admin'; }
function require_login(): void {
    if (!current_user()) { flash('error', 'Please sign in to continue.'); redirect('login'); }
}
function require_admin(): void {
    if (!current_user()) { flash('error', 'Please sign in as an administrator to open the control panel.'); redirect('login'); }
    if (!is_admin()) {
        http_response_code(403);
        layout_header('Access denied');
        echo '<div class="empty-state"><span class="trust-icon">'.icon('lock').'</span><h1>Access denied</h1><p>You are signed in, but this area is restricted to store administrators.</p><a class="button" href="'.e(url('')).'">Back to home</a></div>';
        layout_footer();
        exit;
    }
}
function currency_symbol(string $code): string {
    return match (strtoupper($code)) {
        'USD' => '$',
        'EUR' => '€',
        'GBP' => '£',
        default => '₹',
    };
}
function &settings_store(): array {
    static $store = null;
    if ($store === null) $store = [];
    return $store;
}
function setting(string $key, mixed $default = null): mixed {
    $store = &settings_store();
    if (!array_key_exists($key, $store)) {
        try {
            $st = db()->prepare('SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1');
            $st->execute([$key]);
            $v = $st->fetchColumn();
            $store[$key] = ($v === false || $v === null) ? null : (string)$v;
        } catch (Throwable $ex) {
            $store[$key] = null;
        }
    }
    return $store[$key] ?? $default;
}
function set_setting(string $key, string $value): void {
    $st = db()->prepare('INSERT INTO settings(setting_key,setting_value,updated_at) VALUES(?,?,NOW()) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=NOW()');
    $st->execute([$key, $value]);
    $store = &settings_store();
    $store[$key] = $value;
}
function money(int|string|float|null $amount): string {
    $n = (float)($amount ?? 0);
    return currency_symbol((string)setting('currency', (string)cfg('currency', 'INR'))) . number_format($n, 2);
}
function slugify(string $value): string {
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    return trim($value, '-') ?: 'item-' . bin2hex(random_bytes(3));
}
function product_image(?string $path): string {
    if ($path && preg_match('#^uploads/[a-zA-Z0-9._-]+$#', $path)) return url($path);
    return url('assets/product-placeholder.svg');
}
function cart_items(): array {
    return $_SESSION['cart'] ?? [];
}
function cart_count(): int {
    return array_sum(array_map('intval', cart_items()));
}
function get_categories(bool $activeOnly = true): array {
    $sql = 'SELECT id,name,slug,parent_id FROM categories';
    if ($activeOnly) $sql .= ' WHERE is_active=1';
    $sql .= ' ORDER BY sort_order ASC, name ASC';
    return db()->query($sql)->fetchAll();
}
function get_products(int $limit = 24, ?int $categoryId = null, string $search = ''): array {
    $limit = max(1, min(100, $limit));
    $where = ["p.status='published'"]; $params = [];
    if ($categoryId) {
        $where[] = 'EXISTS (SELECT 1 FROM product_categories pc WHERE pc.product_id=p.id AND pc.category_id=?)';
        $params[] = $categoryId;
    }
    if ($search !== '') {
        $where[] = '(p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ?)';
        $term = '%' . $search . '%'; array_push($params, $term, $term, $term);
    }
    $sql = 'SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id=p.primary_category_id WHERE '
        . implode(' AND ', $where) . ' ORDER BY p.created_at DESC LIMIT ' . $limit;
    $st = db()->prepare($sql); $st->execute($params); return $st->fetchAll();
}
function get_product(int $id): ?array {
    $st = db()->prepare("SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id=p.primary_category_id WHERE p.id=? AND p.status='published' LIMIT 1");
    $st->execute([$id]); $r = $st->fetch(); return $r ?: null;
}
function stock_for(int $productId): int {
    $st = db()->prepare('SELECT stock_qty FROM inventory WHERE product_id=? LIMIT 1');
    $st->execute([$productId]); return (int)($st->fetchColumn() ?: 0);
}
function layout_header(string $title = 'Marketplace'): void {
    $brand = e((string)setting('store_name', (string)cfg('app_name', 'Marketplace')));
    $announcement = trim((string)setting('announcement', ''));
    $user = current_user();
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>'.e($title).' | '.$brand.'</title><meta name="description" content="Discover products across categories at '.$brand.'.">';
    echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
    echo '<link rel="stylesheet" href="'.e(url('assets/style.css')).'"></head><body>';
    echo '<a class="skip-link" href="#main">Skip to content</a>';
    if ($announcement !== '') echo '<div class="announcement" role="status">'.e($announcement).'</div>';
    echo '<header class="site-header"><div class="topbar">';
    echo '<a class="brand" href="'.e(url('')).'" aria-label="'.$brand.' home"><span class="brand-mark">'.icon('bag').'</span>'.$brand.'</a>';
    echo '<form class="search" action="'.e(url('products')).'" method="get" role="search"><input name="q" value="'.e($_GET['q'] ?? '').'" placeholder="Search products, brands and more" aria-label="Search products"><button aria-label="Search">'.icon('search').'Search</button></form>';
    echo '<nav class="quick" aria-label="Account">';
    echo '<a href="'.e(url('account')).'">'.icon('user').'<span class="label">'.($user ? e($user['name'] ?? 'My account') : 'Sign in').'</span></a>';
    echo '<a class="cart-pill" href="'.e(url('cart')).'" aria-label="Cart with '.cart_count().' items">'.icon('cart').'<span>Cart · '.cart_count().'</span></a>';
    echo '</nav>';
    echo '<button class="nav-toggle" type="button" aria-label="Toggle category menu" aria-expanded="false">'.icon('menu').'</button>';
    echo '</div><div class="catnav-wrap"><nav class="catnav" aria-label="Product categories"><a href="'.e(url('products')).'">All products</a><a href="'.e(url('deals')).'">Deals</a>';
    foreach (array_slice(get_categories(), 0, 7) as $cat) echo '<a href="'.e(url('category?id='.$cat['id'])).'">'.e($cat['name']).'</a>';
    echo '</nav></div></header><main class="container" id="main">'; render_flashes();
}
function layout_footer(): void {
    $brand = e((string)setting('store_name', (string)cfg('app_name', 'Marketplace')));
    echo '</main><footer class="footer"><div class="footer-grid">';
    echo '<div><strong>'.$brand.'</strong><p>Shop with clear product details, transparent policies, and support you can reach.</p></div>';
    echo '<div><h3>Shop</h3><nav class="footer-links" aria-label="Shop links"><a href="'.e(url('products')).'">All products</a><a href="'.e(url('categories')).'">Categories</a><a href="'.e(url('deals')).'">Deals</a><a href="'.e(url('new-arrivals')).'">New arrivals</a></nav></div>';
    echo '<div><h3>Help</h3><nav class="footer-links" aria-label="Help links"><a href="'.e(url('contact')).'">Contact us</a><a href="'.e(url('shipping-policy')).'">Shipping policy</a><a href="'.e(url('return-policy')).'">Returns &amp; refunds</a><a href="'.e(url('account')).'">Track your orders</a></nav></div>';
    echo '<div><h3>Company</h3><nav class="footer-links" aria-label="Company links"><a href="'.e(url('about')).'">About us</a><a href="'.e(url('privacy-policy')).'">Privacy policy</a><a href="'.e(url('terms')).'">Terms &amp; conditions</a></nav></div>';
    echo '</div><div class="footer-bottom"><span>© '.date('Y').' '.$brand.'. All rights reserved.</span>';
    echo '<div class="footer-trust"><span>'.icon('lock').'Secure checkout</span><span>'.icon('shield').'Buyer protection</span><span>'.icon('truck').'Pan-India delivery</span></div></div></footer>';
    echo '<script src="'.e(url('assets/app.js')).'" defer></script></body></html>';
}
function safe_upload(string $field): ?string {
    if (empty($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    $f = $_FILES[$field];
    if (($f['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || ($f['size'] ?? 0) > 5 * 1024 * 1024) throw new RuntimeException('Upload failed or file exceeds 5 MB.');
    $finfo = new finfo(FILEINFO_MIME_TYPE); $mime = $finfo->file($f['tmp_name']);
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if (!isset($allowed[$mime])) throw new RuntimeException('Only JPG, PNG, and WebP images are accepted.');
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    $dir = APP_ROOT . '/storage/uploads';
    if (!is_dir($dir)) mkdir($dir, 0750, true);
    if (!move_uploaded_file($f['tmp_name'], $dir.'/'.$name)) throw new RuntimeException('Could not save image.');
    // Public copy only; production hardening should configure storage outside public root and an image-serving controller.
    $publicDir = APP_ROOT . '/public/uploads';
    if (!is_dir($publicDir)) mkdir($publicDir, 0755, true);
    if (!copy($dir.'/'.$name, $publicDir.'/'.$name)) throw new RuntimeException('Could not publish image.');
    return 'uploads/'.$name;
}
