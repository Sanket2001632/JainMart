# Deployment checklist (Hostinger hPanel)

## Before upload
- Confirm exact PHP version and extensions in hPanel.
- Create database and user in hPanel; import `database/schema.sql`.
- Create `config.php` from `config.example.php` outside the public document root.
- Set correct `base_url`, DB values, currency, and a strong unique `app_key`.
- Do not upload `config.php`, `app/`, `database/`, `scripts/`, or `storage/` into a publicly accessible directory.

## Public document root
Preferred: point the domain document root to `marketplace-hostinger/public/`.
If hPanel does not allow it, keep the project in a private directory and copy only `public/` contents to `public_html`. Edit the public entry point's bootstrap path to point to the private project root. Do not move the private config into public_html.

## First administrator
Run from SSH/CLI in the private project directory:
`php scripts/create_admin.php admin@example.com "A-long-random-passphrase-16-chars-or-more" "Store Admin"`
The script refuses web execution. If the hosting plan does not provide CLI/SSH, arrange a one-time secure provisioning procedure with the developer; never deploy an unauthenticated admin registration page.

## Launch blockers
This starter intentionally has no real payment gateway. Configure and test a provider adapter and signed webhooks before online payment is enabled. Taxes, shipping prices, return windows, warranty statements, and legal pages need business approval. The delivery provider remains unconfigured until selected.
