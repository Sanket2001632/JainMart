<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("CLI only\n"); }
require dirname(__DIR__) . '/app/bootstrap.php';

$products = [
    ['Bluetooth Earbuds', 'EB-2201', 1499.00, 30, 1, 'seed-earbuds.svg', 'Wireless earbuds with punchy bass, a pocket charging case, and up to 24 hours of combined playtime. Sweat-resistant and ready for commutes or workouts.'],
    ['Smart Watch', 'SW-2202', 2999.00, 15, 1, 'seed-smartwatch.svg', 'AMOLED smartwatch with heart-rate tracking, sleep insights, and call notifications on your wrist. Week-long battery life on a single charge.'],
    ['Aluminium Laptop Stand', 'LS-2203', 1099.00, 25, 1, 'seed-stand.svg', 'Foldable aluminium riser that lifts your laptop to eye level and keeps it cool. Anti-slip pads protect your device on any desk.'],
    ['Men\'s Cotton Kurta', 'MK-2204', 899.00, 40, 2, 'seed-kurta.svg', 'Breathable cotton kurta with a clean mandarin collar — easy festive polish or everyday comfort. Pair with jeans or churidar.'],
    ['Men\'s Oversized Tee', 'MT-2205', 549.00, 50, 2, 'seed-tee.svg', 'Heavyweight cotton tee in a relaxed oversized fit. Pre-shrunk, bio-washed, and built to hold its shape wash after wash.'],
    ['Women\'s Handbag', 'HB-2206', 1299.00, 20, 3, 'seed-handbag.svg', 'Structured everyday handbag with a roomy main compartment, inner zip pocket, and sturdy top handles. Goes from office to evening.'],
    ['LED Table Lamp', 'TL-2207', 749.00, 35, 4, 'seed-lamp.svg', 'Warm dimmable LED lamp with three brightness levels and a touch dimmer. USB-powered — perfect for desks and bedside tables.'],
    ['Non-stick Cookware Set', 'CS-2208', 2499.00, 12, 4, 'seed-cookware.svg', 'Five-piece non-stick cookware set with heat-resistant handles and induction-compatible bases. Cook with less oil, clean in seconds.'],
    ['Vitamin C Face Wash', 'FW-2209', 399.00, 60, 5, 'seed-facewash.svg', 'Gentle foaming face wash with vitamin C and aloe vera for a bright, fresh finish. Suits all skin types, twice daily.'],
    ['Cricket Bat (English Willow)', 'CB-2210', 1899.00, 18, 6, 'seed-bat.svg', 'Grade-A English willow bat with a thick edges and balanced pickup. Knocked and ready for tennis or leather ball play.'],
    ['Yoga Mat 6mm', 'YM-2211', 699.00, 45, 6, 'seed-yogamat.svg', 'Non-slip 6mm TPE yoga mat with alignment lines and a carry strap. Cushioned for joints, lightweight for the studio or park.'],
    ['Hardcover Notebook Set', 'NB-2212', 349.00, 80, 7, 'seed-notebook.svg', 'Set of three A5 hardcover notebooks with 200 dotted pages each. Lies flat, takes fountain pen ink without bleeding.'],
    ['Dinosaur Puzzle Toy', 'DP-2213', 599.00, 25, 8, 'seed-dino.svg', '64-piece dinosaur jigsaw for ages 5+. Sturdy pieces, vivid colours, and a finished size big enough to frame.'],
];

$pdo = db();
$stSku = $pdo->prepare('SELECT id FROM products WHERE sku=? LIMIT 1');
$stProd = $pdo->prepare('INSERT INTO products(name,slug,sku,description,price,condition_label,primary_category_id,status,image_path,created_at,updated_at) VALUES(?,?,?,?,?,\'new\',?,\'published\',?,NOW(),NOW())');
$stLink = $pdo->prepare('INSERT INTO product_categories(product_id,category_id) VALUES(?,?)');
$stInv = $pdo->prepare('INSERT INTO inventory(product_id,stock_qty) VALUES(?,?)');
$stMove = $pdo->prepare("INSERT INTO inventory_movements(product_id,quantity_delta,reason,reference_type,reference_id,created_at) VALUES(?,?,'initial_stock','product',?,NOW())");

$created = 0; $skipped = 0;
foreach ($products as [$name, $sku, $price, $stock, $catId, $img, $desc]) {
    $stSku->execute([$sku]);
    if ($stSku->fetchColumn()) { $skipped++; continue; }
    $slug = slugify($name);
    $pdo->beginTransaction();
    try {
        $stProd->execute([$name, $slug, $sku, $desc, (string)$price, $catId, 'uploads/'.$img]);
        $id = (int)$pdo->lastInsertId();
        $stLink->execute([$id, $catId]);
        $stInv->execute([$id, $stock]);
        $stMove->execute([$id, $stock, (string)$id]);
        $pdo->commit();
        $created++;
        fwrite(STDOUT, "Created #$id $name ($sku)\n");
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        fwrite(STDERR, "Failed: $sku — {$ex->getMessage()}\n");
        exit(1);
    }
}

$pdo->prepare("UPDATE products SET image_path='uploads/seed-mouse.svg', updated_at=NOW() WHERE image_path='uploads/03d91330a8161b48d4845546febb7f18.png'")->execute();

$total = (int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
fwrite(STDOUT, "Done. created=$created skipped=$skipped products_total=$total (mouse image repointed to seed-mouse.svg)\n");
