<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("CLI only\n"); }
require dirname(__DIR__) . '/app/bootstrap.php';
if ($argc < 4) {
    fwrite(STDERR, "Usage: php scripts/create_admin.php admin@example.com \"Strong Passphrase Here\" \"Store Admin\"\n");
    exit(2);
}
$email = strtolower(trim($argv[1])); $password = (string)$argv[2]; $name = trim((string)$argv[3]);
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 16 || $name === '') {
    fwrite(STDERR, "Provide a valid email, name, and password of at least 16 characters.\n"); exit(2);
}
$st = db()->prepare("INSERT INTO users(name,email,password_hash,role,status,created_at) VALUES(?,?,?,'admin','active',NOW())");
try {
    $st->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
    fwrite(STDOUT, "Administrator created. Store credentials securely and remove no security controls.\n");
} catch (Throwable $e) {
    fwrite(STDERR, "Could not create admin. The email may already exist or DB configuration is incorrect.\n"); exit(1);
}
