# Marketplace Hostinger Starter

A PHP + MySQL starter for a single-vendor, multi-category e-commerce store designed for shared hosting. It includes a responsive storefront, dynamic categories/products, cart, basic checkout/order creation, customer registration/login, protected admin, product/category/order administration, manual shipment fields, and a future shipping integration placeholder.

## Important status
This is a **deployable starter foundation**, not a fully certified production commerce system. A real payment gateway is intentionally not wired because the client has not selected a provider. Checkout in this starter creates an order with `payment_status=pending`; it does not claim online payment is completed. Do not accept online payments until a gateway adapter with signed webhook verification, idempotency, reconciliation and refunds has been implemented and tested. Delivery API is intentionally unconfigured; manual shipment fields are available.

## Requirements
- PHP 8.1+ recommended (confirm the actual supported version in hPanel)
- PHP extensions: PDO, pdo_mysql, mbstring, fileinfo; session support
- MySQL 8 / compatible MariaDB
- HTTPS in production

## Local setup
1. Create a MySQL database.
2. Import `database/schema.sql`.
3. Copy `config.example.php` to `config.php` and set DB values and a long random `APP_KEY`.
4. Configure your web server document root to this project's `public/` directory.
5. For local testing, run from project root:
   `php -S 127.0.0.1:8080 -t public`
6. Open `http://127.0.0.1:8080`.
7. Create the first administrator using the one-time CLI bootstrap:
   `php scripts/create_admin.php admin@example.com "Strong Passphrase Here" "Store Admin"`

   Optional demo catalog (13 products with illustrations, CLI-only and idempotent):
   `php scripts/seed_demo_products.php`
   The script is intentionally CLI-only and refuses web execution. Keep the script outside the public document root.

## Hostinger deployment
1. Create a MySQL database/user in hPanel and grant only required privileges.
2. Import `database/schema.sql` through phpMyAdmin.
3. Upload project files outside `public_html` where possible; put only the contents of `public/` in the domain's document root. If the plan permits changing the document root, point it to `project/public`.
4. If the document root cannot be changed, place application files in a private directory outside `public_html`, copy `public/` contents into `public_html`, and update `public/index.php`'s bootstrap path to the private project location. Do not expose `config.php`, `app/`, `database/`, `storage/`, or `scripts/`.
5. Copy `config.example.php` to `config.php` in the private project root; set database credentials, HTTPS base URL and a random secret. Never upload a real config file into public_html.
6. Ensure `storage/` is writable by the PHP process but not web-browsable. Disable script execution in uploads.
7. Use HTTPS, disable debug, create admin through SSH/CLI if available. If no CLI access is available, ask the developer to provide a one-time protected provisioning workflow; do not expose an open admin-creation endpoint.
8. Configure SMTP and real payment provider only after selection. The delivery integration page must remain "Not configured" until tested.
9. Test checkout, order emails, access control, backup/restore and mobile layout before launch.

## Starter routes
- `/` home
- `/products` catalog
- `/product?id=1` product detail
- `/category?id=1` category listing
- `/cart` cart
- `/checkout` creates an order as pending payment (no live payment processing)
- `/login`, `/register`, `/logout`
- `/account` customer orders
- `/admin` dashboard
- `/admin/products`, `/admin/categories`, `/admin/orders`, `/admin/shipping`, `/admin/users`, `/admin/settings`

## Security notes
- Replace all demo content before launch.
- Use a strong unique APP_KEY and database password.
- No raw card details are stored.
- Do not expose debug output in production.
- This starter has basic safeguards but still requires an independent security review and completion of production-grade payment, refund, email verification, tax/shipping rules, rate limiting, audit coverage, backups and testing.
