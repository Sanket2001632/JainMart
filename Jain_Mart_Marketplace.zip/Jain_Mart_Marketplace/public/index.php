<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';

$path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/', '/');
$basePath = trim(parse_url((string)cfg('base_url',''), PHP_URL_PATH) ?? '', '/');
if ($basePath !== '' && str_starts_with($path, $basePath)) $path = trim(substr($path, strlen($basePath)), '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

function page_heading(string $title, string $subtitle=''): void {
    echo '<div class="page-heading"><h1>'.e($title).'</h1>'.($subtitle ? '<p>'.e($subtitle).'</p>' : '').'</div>';
}
function product_card(array $p): void {
    $stock = stock_for((int)$p['id']);
    echo '<article class="product-card"><a href="'.e(url('product?id='.(int)$p['id'])).'" aria-label="'.e($p['name']).'"><img src="'.e(product_image($p['image_path'] ?? null)).'" alt="'.e($p['name']).'" loading="lazy"></a>';
    echo '<div class="product-body"><p class="eyebrow">'.e($p['category_name'] ?? 'Featured').'</p><h3><a href="'.e(url('product?id='.(int)$p['id'])).'">'.e($p['name']).'</a></h3>';
    echo '<p class="price">'.money($p['price']).'</p><p class="product-meta">'.condition_badge($p['condition_label'] ?? null).stock_badge($stock).'</p>';
    echo '<form method="post" action="'.e(url('cart/add')).'">'.csrf_field().'<input type="hidden" name="product_id" value="'.(int)$p['id'].'"><input type="hidden" name="quantity" value="1"><button '.($stock<1?'disabled':'').'>Add to cart</button></form></div></article>';
}
function page_products(): void {
    $q = trim((string)($_GET['q'] ?? '')); $categoryId = isset($_GET['category_id']) ? (int)$_GET['category_id'] : null;
    $sort = (string)($_GET['sort'] ?? 'newest');
    $products = get_products(60, $categoryId, $q);
    if ($sort === 'price_asc') usort($products, fn($a,$b)=>(float)$a['price']<=>(float)$b['price']);
    if ($sort === 'price_desc') usort($products, fn($a,$b)=>(float)$b['price']<=>(float)$a['price']);
    layout_header($q ? 'Search: '.$q : 'Products');
    echo '<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="'.e(url('')).'">Home</a><span class="sep">/</span><span>Products</span></nav>';
    page_heading($q ? 'Search results' : 'Shop all products', $q ? 'Results for “'.$q.'”' : 'Explore our latest catalog.');
    echo '<form class="toolbar" method="get" action="'.e(url('products')).'"><input name="q" value="'.e($q).'" placeholder="Search products"><select name="sort"><option value="newest">Newest</option><option value="price_asc" '.($sort==='price_asc'?'selected':'').'>Price: low to high</option><option value="price_desc" '.($sort==='price_desc'?'selected':'').'>Price: high to low</option></select><button>Apply</button></form>';
    echo '<div class="product-grid">';
    foreach ($products as $p) product_card($p);
    if (!$products) echo '<div class="empty-state" style="grid-column:1/-1"><span class="trust-icon">'.icon('search').'</span><h2>No products found</h2><p>Try a different search term or browse all categories.</p><a class="button" href="'.e(url('products')).'">View all products</a></div>';
    echo '</div>'; layout_footer();
}
try {
    if ($path === '' || $path === 'index.php') {
        layout_header('Home');
        $heroTitle = (string)setting('hero_title', 'Find your next favourite.');
        $heroSub = (string)setting('hero_subtitle', 'Explore useful finds across fashion, electronics, home, and everyday essentials — with clear product details and transparent policies.');
        echo '<section class="hero"><div><span class="eyebrow light">A smarter way to shop</span><h1>'.e($heroTitle).'</h1><p>'.e($heroSub).'</p>';
        echo '<div class="hero-actions"><a class="button accent" href="'.e(url('products')).'">Explore products'.icon('arrow-right').'</a><a class="button light-button" href="'.e(url('categories')).'">Browse categories</a></div>';
        echo '<div class="hero-note"><span>'.icon('truck').'Free delivery over ₹999</span><span>'.icon('refresh').'Easy 7-day returns</span><span>'.icon('shield').'Secure checkout</span></div></div>';
        echo '<img class="hero-image" src="'.e(url('assets/hero-banner.svg')).'" alt="" aria-hidden="true" width="1200" height="540"></section>';
        echo '<div class="trust-strip">';
        echo '<div class="trust-item"><span class="trust-icon">'.icon('truck').'</span><div><b>Fast, tracked delivery</b><span>Dispatch within 24–48 hours with live tracking.</span></div></div>';
        echo '<div class="trust-item"><span class="trust-icon">'.icon('refresh').'</span><div><b>Easy returns</b><span>7-day hassle-free returns on eligible products.</span></div></div>';
        echo '<div class="trust-item"><span class="trust-icon">'.icon('support').'</span><div><b>Helpful support</b><span>Real people, easy-to-find policies, clear answers.</span></div></div>';
        echo '</div>';
        echo '<div class="promo-grid">';
        echo '<a class="promo-tile" href="'.e(url('deals')).'"><img src="'.e(url('assets/promo-deals.svg')).'" alt="" aria-hidden="true"><span><b>Deals of the week</b><small>Hand-picked price drops</small></span></a>';
        echo '<a class="promo-tile" href="'.e(url('new-arrivals')).'"><img src="'.e(url('assets/promo-new.svg')).'" alt="" aria-hidden="true"><span><b>Fresh arrivals</b><small>New drops across every category</small></span></a>';
        echo '<a class="promo-tile" href="'.e(url('categories')).'"><img src="'.e(url('assets/promo-cats.svg')).'" alt="" aria-hidden="true"><span><b>Browse all categories</b><small>Eight departments, one cart</small></span></a>';
        echo '</div>';
        echo '<section class="section"><div class="section-title"><h2>Shop by category</h2><a href="'.e(url('categories')).'">View all →</a></div><div class="category-grid">';
        foreach (array_slice(get_categories(),0,12) as $c) echo '<a class="category-tile" href="'.e(url('category?id='.(int)$c['id'])).'">'.e($c['name']).'<span>Explore '.icon('arrow-right').'</span></a>';
        echo '</div></section><section class="section"><div class="section-title"><h2>Featured finds</h2><a href="'.e(url('products')).'">Shop all →</a></div><div class="product-grid">';
        $featured = get_products(8);
        foreach ($featured as $p) product_card($p);
        if (!$featured) echo '<div class="empty-state" style="grid-column:1/-1"><span class="trust-icon">'.icon('package').'</span><h2>Fresh stock is on the way</h2><p>New products will appear here soon. Browse categories in the meantime.</p><a class="button" href="'.e(url('categories')).'">Browse categories</a></div>';
        echo '</div></section>';
        layout_footer();
    } elseif ($path === 'products' || $path === 'search') {
        page_products();
    } elseif ($path === 'categories') {
        layout_header('Categories');
        echo '<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="'.e(url('')).'">Home</a><span class="sep">/</span><span>Categories</span></nav>';
        page_heading('All categories','Browse the catalog by department.');
        echo '<div class="category-grid">';
        foreach (get_categories() as $c) echo '<a class="category-tile" href="'.e(url('category?id='.(int)$c['id'])).'">'.e($c['name']).'<span>Shop category '.icon('arrow-right').'</span></a>';
        echo '</div>'; layout_footer();
    } elseif ($path === 'category') {
        $id=(int)($_GET['id']??0); $st=db()->prepare('SELECT * FROM categories WHERE id=? AND is_active=1'); $st->execute([$id]); $cat=$st->fetch();
        if (!$cat) { http_response_code(404); layout_header('Category not found'); page_heading('Category not found'); layout_footer(); }
        else {
            $_GET['category_id']=$id; layout_header($cat['name']);
            echo '<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="'.e(url('')).'">Home</a><span class="sep">/</span><a href="'.e(url('categories')).'">Categories</a><span class="sep">/</span><span>'.e($cat['name']).'</span></nav>';
            page_heading($cat['name'],$cat['description'] ?? 'Explore products in this category.');
            $items = get_products(60,$id);
            echo '<div class="product-grid">';
            foreach($items as $p) product_card($p);
            if(!$items) echo '<div class="empty-state" style="grid-column:1/-1"><span class="trust-icon">'.icon('package').'</span><h2>Nothing here yet</h2><p>No products in this category right now — check back soon.</p><a class="button" href="'.e(url('products')).'">Browse all products</a></div>';
            echo '</div>'; layout_footer();
        }
    } elseif ($path === 'product') {
        $p=get_product((int)($_GET['id']??0));
        if (!$p) { http_response_code(404); layout_header('Product not found'); page_heading('Product not found'); layout_footer(); }
        else {
            $stock = stock_for((int)$p['id']);
            layout_header($p['name']);
            echo '<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="'.e(url('')).'">Home</a><span class="sep">/</span><a href="'.e(url('products')).'">Products</a><span class="sep">/</span><span>'.e($p['name']).'</span></nav>';
            echo '<div class="product-detail"><div><img class="detail-image" src="'.e(product_image($p['image_path']??null)).'" alt="'.e($p['name']).'"></div><div><p class="eyebrow">'.e($p['category_name']??'Product').'</p><h1>'.e($p['name']).'</h1><p class="price large">'.money($p['price']).'</p>';
            echo '<p class="condition">'.condition_badge($p['condition_label']).' '.stock_badge($stock).'</p><p>'.nl2br(e($p['description'])).'</p>';
            echo '<form method="post" action="'.e(url('cart/add')).'" class="add-form">'.csrf_field().'<input type="hidden" name="product_id" value="'.(int)$p['id'].'"><label>Quantity <input type="number" name="quantity" value="1" min="1" max="10"></label><button class="accent" '.($stock<1?'disabled':'').'>Add to cart</button></form>';
            echo '<ul class="detail-points"><li>'.icon('truck').'Dispatch in 24–48 hours</li><li>'.icon('refresh').'Easy 7-day returns on eligible items</li><li>'.icon('shield').'Secure checkout — no card details stored</li><li>'.icon('support').'Support before and after you order</li></ul>';
            echo '<p class="muted" style="margin-top:var(--space-4)">Review the condition, included accessories, warranty and return terms before ordering.</p></div></div>'; layout_footer();
        }
    } elseif ($path === 'cart/add' && $method === 'POST') {
        verify_csrf(); $id=(int)($_POST['product_id']??0); $qty=max(1,min(10,(int)($_POST['quantity']??1))); $p=get_product($id);
        if (!$p || stock_for($id)<$qty) { flash('error','This item is unavailable in the requested quantity.'); redirect('cart'); }
        $_SESSION['cart'][$id]=min(stock_for($id),((int)($_SESSION['cart'][$id]??0))+$qty); flash('success','Added to cart.'); redirect('cart');
    } elseif ($path === 'cart') {
        if ($method==='POST') {
            verify_csrf(); foreach(($_POST['qty']??[]) as $id=>$qty) { $id=(int)$id; $qty=(int)$qty; if($qty<=0) unset($_SESSION['cart'][$id]); else $_SESSION['cart'][$id]=min(10,max(1,$qty)); }
            flash('success','Cart updated.'); redirect('cart');
        }
        layout_header('Your cart');
        echo '<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="'.e(url('')).'">Home</a><span class="sep">/</span><span>Cart</span></nav>';
        page_heading('Your cart','Review items before checkout.');
        $items=[]; $subtotal=0;
        foreach(cart_items() as $id=>$qty) { $p=get_product((int)$id); if($p) { $p['qty']=(int)$qty; $p['line']=(float)$p['price']*(int)$qty; $subtotal+=$p['line']; $items[]=$p; } }
        if(!$items) echo '<div class="empty-state"><span class="trust-icon">'.icon('cart').'</span><h2>Your cart is empty</h2><p>Discover something you love and add it to your cart.</p><a class="button" href="'.e(url('products')).'">Browse products</a></div>';
        else {
            echo '<form method="post">'.csrf_field().'<div class="cart-layout"><div class="cart-items">';
            foreach($items as $it) echo '<div class="cart-row"><img src="'.e(product_image($it['image_path']??null)).'" alt=""><div class="cart-info"><b>'.e($it['name']).'</b><span>'.money($it['price']).' each</span><label>Qty <input type="number" name="qty['.(int)$it['id'].']" min="0" max="10" value="'.(int)$it['qty'].'" aria-label="Quantity for '.e($it['name']).'"></label></div><strong>'.money($it['line']).'</strong></div>';
            echo '<div><button class="secondary">Update cart</button></div></div><aside class="summary"><h2>Order summary</h2><p>Subtotal <b>'.money($subtotal).'</b></p><p>Shipping <span>Confirmed before fulfilment</span></p><p class="total">Total <b>'.money($subtotal).'</b></p><p class="muted">Tax and shipping rules need client confirmation. Payment is collected after order confirmation — no online payment is processed yet.</p><a class="button accent full" href="'.e(url('checkout')).'">Continue to checkout</a></aside></div></form>';
        }
        layout_footer();
    } elseif ($path === 'register') {
        if($method==='POST') {
            verify_csrf(); $name=trim((string)($_POST['name']??'')); $email=strtolower(trim((string)($_POST['email']??''))); $password=(string)($_POST['password']??'');
            if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<12) { flash('error','Enter a name, valid email, and password of at least 12 characters.'); redirect('register'); }
            try { $st=db()->prepare("INSERT INTO users(name,email,password_hash,role,status,created_at) VALUES(?,?,?,'customer','active',NOW())"); $st->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]); flash('success','Account created. Please sign in.'); redirect('login'); }
            catch(PDOException $ex) { flash('error','Could not create account. The email may already be registered.'); redirect('register'); }
        }
        layout_header('Create account');
        echo '<div class="auth-wrap"><div class="auth-aside"><span class="trust-icon">'.icon('user').'</span><h1 style="font-size:26px">Create your account</h1><p class="muted">Track orders, faster checkout, and easy returns — all in one place.</p></div>';
        echo '<form class="form-card auth-card" method="post">'.csrf_field().'<label>Full name<input name="name" required maxlength="120" autocomplete="name"></label><label>Email<input type="email" name="email" required maxlength="190" autocomplete="email"></label><label>Password<input type="password" name="password" minlength="12" required autocomplete="new-password" aria-describedby="pw-hint"></label><span class="hint" id="pw-hint">Use at least 12 characters — a mix of words, numbers and symbols works best.</span><button style="margin-top:var(--space-4)">Create account</button><p>Already registered? <a href="'.e(url('login')).'">Sign in</a></p></form></div>'; layout_footer();
    } elseif ($path === 'login') {
        if($method==='POST') {
            verify_csrf(); $email=strtolower(trim((string)($_POST['email']??''))); $password=(string)($_POST['password']??'');
            $st=db()->prepare("SELECT id,name,email,password_hash,role,status FROM users WHERE email=? LIMIT 1"); $st->execute([$email]); $u=$st->fetch();
            if($u && $u['status']==='active' && password_verify($password,$u['password_hash'])) {
                session_regenerate_id(true); unset($u['password_hash']); $_SESSION['user']=$u; flash('success','Signed in successfully.'); redirect(($u['role']==='admin')?'admin':'account');
            }
            usleep(350000); flash('error','Invalid email or password.'); redirect('login');
        }
        layout_header('Sign in');
        echo '<div class="auth-wrap"><div class="auth-aside"><span class="trust-icon">'.icon('lock').'</span><h1 style="font-size:26px">Welcome back</h1><p class="muted">Sign in to manage your orders and account.</p></div>';
        echo '<form class="form-card auth-card" method="post">'.csrf_field().'<label>Email<input type="email" name="email" required autocomplete="username"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button>Sign in</button><p>New here? <a href="'.e(url('register')).'">Create account</a></p></form></div>'; layout_footer();
    } elseif ($path === 'logout' && $method==='POST') {
        verify_csrf(); $_SESSION=[]; if(ini_get('session.use_cookies')) { $p=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$p['path'],$p['domain']??'',$p['secure'],$p['httponly']); } session_destroy(); redirect('');
    } elseif ($path === 'account') {
        require_login(); layout_header('My account'); page_heading('Hello, '.current_user()['name'],'Your account and recent orders.');
        echo '<div class="panel"><h2>Account</h2><p>'.e(current_user()['email']).'</p><form method="post" action="'.e(url('logout')).'">'.csrf_field().'<button class="secondary">Sign out</button></form></div><section class="section"><div class="section-title"><h2>Your orders</h2></div>';
        $st=db()->prepare('SELECT id,order_number,status,payment_status,grand_total,created_at FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 30'); $st->execute([current_user()['id']]); $orders=$st->fetchAll();
        if(!$orders) echo '<div class="empty-state"><span class="trust-icon">'.icon('clipboard').'</span><h2>No orders yet</h2><p>When you place an order, it will show up here with live status.</p><a class="button" href="'.e(url('products')).'">Start shopping</a></div>';
        else { echo '<div class="table-wrap"><table><tr><th>Order</th><th>Date</th><th>Status</th><th>Payment</th><th>Total</th></tr>'; foreach($orders as $o) echo '<tr><td><b>'.e($o['order_number']).'</b></td><td>'.e($o['created_at']).'</td><td>'.status_badge($o['status']).'</td><td>'.status_badge($o['payment_status']).'</td><td><b>'.money($o['grand_total']).'</b></td></tr>'; echo '</table></div>'; }
        echo '</section>'; layout_footer();
    } elseif ($path === 'checkout') {
        require_login();
        if($method==='POST') {
            verify_csrf(); $address=trim((string)($_POST['address']??'')); $phone=trim((string)($_POST['phone']??''));
            if($address===''||$phone==='') { flash('error','Address and phone are required.'); redirect('checkout'); }
            $cart=cart_items(); if(!$cart) { flash('error','Your cart is empty.'); redirect('cart'); }
            $pdo=db();
            try {
                $pdo->beginTransaction(); $subtotal=0; $rows=[];
                foreach($cart as $id=>$qty) {
                    $st=$pdo->prepare("SELECT p.*, i.stock_qty FROM products p JOIN inventory i ON i.product_id=p.id WHERE p.id=? AND p.status='published' FOR UPDATE");
                    $st->execute([(int)$id]); $p=$st->fetch();
                    if(!$p || (int)$p['stock_qty']<(int)$qty) throw new RuntimeException('Stock changed for one or more items. Please update your cart.');
                    $subtotal+=(float)$p['price']*(int)$qty; $rows[]=[$p,(int)$qty];
                }
                $orderNo='ORD-'.date('Y').'-'.strtoupper(bin2hex(random_bytes(4)));
                $st=$pdo->prepare("INSERT INTO orders(order_number,user_id,status,payment_status,shipment_status,currency,subtotal,discount,tax,shipping,grand_total,shipping_address,phone,created_at) VALUES(?,?,'pending_confirmation','pending','not_shipped',?, ?,0,0,0,?,?,?,NOW())");
                $st->execute([$orderNo,current_user()['id'],(string)setting('currency',(string)cfg('currency','INR')),$subtotal,$subtotal,$address,$phone]); $orderId=(int)$pdo->lastInsertId();
                foreach($rows as [$p,$qty]) {
                    $st=$pdo->prepare('INSERT INTO order_items(order_id,product_id,product_name_snapshot,sku_snapshot,condition_snapshot,unit_price,quantity,line_total) VALUES(?,?,?,?,?,?,?,?)');
                    $st->execute([$orderId,$p['id'],$p['name'],$p['sku'],$p['condition_label'],$p['price'],$qty,(float)$p['price']*$qty]);
                    $st=$pdo->prepare('UPDATE inventory SET stock_qty=stock_qty-? WHERE product_id=? AND stock_qty>=?'); $st->execute([$qty,$p['id'],$qty]);
                    if($st->rowCount()!==1) throw new RuntimeException('Stock changed during checkout. Please try again.');
                    $st=$pdo->prepare("INSERT INTO inventory_movements(product_id,quantity_delta,reason,reference_type,reference_id,created_at) VALUES(?,?,'order_pending','order',?,NOW())");
                    $st->execute([$p['id'],-$qty,''.$orderId]);
                }
                $pdo->commit(); unset($_SESSION['cart']); flash('success','Order '.$orderNo.' created. Payment is pending; no online payment was collected by this starter.'); redirect('account');
            } catch(Throwable $ex) {
                if($pdo->inTransaction()) $pdo->rollBack();
                flash('error',$ex instanceof RuntimeException ? $ex->getMessage() : 'Could not create order. Please try again.'); redirect('cart');
            }
        }
        layout_header('Checkout');
        echo '<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="'.e(url('')).'">Home</a><span class="sep">/</span><a href="'.e(url('cart')).'">Cart</a><span class="sep">/</span><span>Checkout</span></nav>';
        page_heading('Checkout','Review delivery details and place your order.');
        $cart=cart_items(); $subtotal=0; foreach($cart as $id=>$qty) { $p=get_product((int)$id); if($p) $subtotal+=(float)$p['price']*(int)$qty; }
        echo '<div class="checkout-layout"><div><div class="info-banner">'.icon('info').'<span>No online payment is taken yet — your order is created with payment status <b>pending</b>, and the store confirms payment manually.</span></div>';
        echo '<form class="form-card" method="post">'.csrf_field().'<h2>Delivery details</h2><label>Phone<input name="phone" required maxlength="30" autocomplete="tel" inputmode="tel" placeholder="10-digit mobile number"></label><label>Full delivery address<textarea name="address" required rows="4" autocomplete="street-address" placeholder="House / flat, street, area, city, PIN code"></textarea></label><button class="accent full" '.(!$cart?'disabled':'').'>Place order (payment pending)</button></form></div><aside class="summary"><h2>Summary</h2><p>Subtotal <b>'.money($subtotal).'</b></p><p>Shipping/tax <span>Not configured</span></p><p class="total">Total <b>'.money($subtotal).'</b></p><p class="muted">Configure pricing, taxes, shipping and a payment provider before production launch.</p></aside></div>'; layout_footer();
    } elseif (str_starts_with($path, 'admin')) {
        require_admin();
        $sub=trim(substr($path,5),'/');
        if($sub==='') {
            layout_header('Admin dashboard'); page_heading('Store administration','Full control panel — catalog, orders, users and site settings.');
            echo '<div class="admin-grid"><a class="admin-card" href="'.e(url('admin/products')).'"><span class="trust-icon">'.icon('package').'</span><b>Products</b><span>Catalog, prices and stock</span></a><a class="admin-card" href="'.e(url('admin/categories')).'"><span class="trust-icon">'.icon('tags').'</span><b>Categories</b><span>Departments and navigation</span></a><a class="admin-card" href="'.e(url('admin/orders')).'"><span class="trust-icon">'.icon('clipboard').'</span><b>Orders</b><span>Review order status</span></a><a class="admin-card" href="'.e(url('admin/shipping')).'"><span class="trust-icon">'.icon('truck').'</span><b>Shipping</b><span>Manual tracking and integration status</span></a><a class="admin-card" href="'.e(url('admin/users')).'"><span class="trust-icon">'.icon('user').'</span><b>Users</b><span>Customers, staff and access</span></a><a class="admin-card" href="'.e(url('admin/settings')).'"><span class="trust-icon">'.icon('lock').'</span><b>Settings</b><span>Store name, currency and banners</span></a></div>';
            $stats=db()->query("SELECT (SELECT COUNT(*) FROM products) products,(SELECT COUNT(*) FROM orders) orders,(SELECT COUNT(*) FROM users WHERE role='customer') customers,(SELECT COUNT(*) FROM users WHERE role='admin') admins,(SELECT COALESCE(SUM(o.grand_total),0) FROM orders o WHERE o.status<>'cancelled') revenue,(SELECT COUNT(*) FROM products p LEFT JOIN inventory i ON i.product_id=p.id WHERE p.status='published' AND COALESCE(i.stock_qty,0)=0) out_of_stock")->fetch();
            echo '<div class="stats"><div><span>Products</span><b>'.(int)$stats['products'].'</b></div><div><span>Orders</span><b>'.(int)$stats['orders'].'</b></div><div><span>Customers</span><b>'.(int)$stats['customers'].'</b></div><div><span>Admins</span><b>'.(int)$stats['admins'].'</b></div><div><span>Revenue</span><b>'.money($stats['revenue']).'</b></div><div><span>Out of stock</span><b>'.(int)$stats['out_of_stock'].'</b></div></div>';
            $recent=db()->query('SELECT o.order_number,o.status,o.payment_status,o.grand_total,o.created_at,u.name FROM orders o LEFT JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 5')->fetchAll();
            echo '<section class="section"><div class="section-title"><h2>Recent orders</h2><a href="'.e(url('admin/orders')).'">View all →</a></div>';
            if(!$recent) echo '<div class="empty-state"><span class="trust-icon">'.icon('clipboard').'</span><h2>No orders yet</h2><p>New orders will appear here as customers check out.</p></div>';
            else { echo '<div class="table-wrap"><table><tr><th>Order</th><th>Customer</th><th>Date</th><th>Payment</th><th>Status</th><th>Total</th></tr>'; foreach($recent as $o) echo '<tr><td><b>'.e($o['order_number']).'</b></td><td>'.e($o['name']??'Guest').'</td><td><small>'.e($o['created_at']).'</small></td><td>'.status_badge($o['payment_status']).'</td><td>'.status_badge($o['status']).'</td><td><b>'.money($o['grand_total']).'</b></td></tr>'; echo '</table></div>'; }
            echo '</section>'; layout_footer();
        } elseif($sub==='products') {
            if($method==='POST') {
                verify_csrf(); $id=(int)($_POST['id']??0); $name=trim((string)($_POST['name']??'')); $price=(float)($_POST['price']??0); $stock=max(0,(int)($_POST['stock_qty']??0)); $category=(int)($_POST['category_id']??0);
                if($name===''||$price<0||$category<1) { flash('error','Name, non-negative price and category are required.'); redirect('admin/products'); }
                try {
                    $image=safe_upload('image'); $slug=slugify($name); $sku=trim((string)($_POST['sku']??'')) ?: strtoupper(substr(hash('sha256',$name.microtime()),0,12));
                    if($id>0) {
                        $st=db()->prepare('UPDATE products SET name=?,slug=?,sku=?,description=?,price=?,condition_label=?,primary_category_id=?,status=?,updated_at=NOW()'.($image?',image_path=?':'').' WHERE id=?');
                        $args=[$name,$slug,$sku,trim((string)($_POST['description']??'')),$price,(string)($_POST['condition_label']??'condition_not_specified'),$category,(string)($_POST['status']??'draft')];
                        if($image) $args[]=$image; $args[]=$id; $st->execute($args);
                        $st=db()->prepare('UPDATE inventory SET stock_qty=? WHERE product_id=?'); $st->execute([$stock,$id]);
                    } else {
                        $st=db()->prepare('INSERT INTO products(name,slug,sku,description,price,condition_label,primary_category_id,status,image_path,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,NOW(),NOW())');
                        $st->execute([$name,$slug,$sku,trim((string)($_POST['description']??'')),(string)$price,(string)($_POST['condition_label']??'condition_not_specified'),$category,(string)($_POST['status']??'draft'),$image]);
                        $id=(int)db()->lastInsertId(); $st=db()->prepare('INSERT INTO product_categories(product_id,category_id) VALUES(?,?)'); $st->execute([$id,$category]); $st=db()->prepare('INSERT INTO inventory(product_id,stock_qty) VALUES(?,?)'); $st->execute([$id,$stock]);
                        $st=db()->prepare("INSERT INTO inventory_movements(product_id,quantity_delta,reason,reference_type,reference_id,created_at) VALUES(?,?,'initial_stock','product',?,NOW())"); $st->execute([$id,$stock,(string)$id]);
                    }
                    flash('success','Product saved.'); redirect('admin/products');
                } catch(Throwable $ex) { flash('error','Could not save product. Check SKU uniqueness, category, and uploaded image.'); redirect('admin/products'); }
            }
            layout_header('Admin products'); page_heading('Products','Create and manage catalog items.');
            $cats=get_categories(false);
            echo '<form class="form-card" method="post" enctype="multipart/form-data">'.csrf_field().'<h2>Add product</h2><div class="form-grid"><label>Product name<input name="name" required></label><label>SKU<input name="sku"></label><label>Price (INR)<input type="number" name="price" min="0" step="0.01" required></label><label>Stock quantity<input type="number" name="stock_qty" min="0" value="0" required></label><label>Category<select name="category_id" required><option value="">Choose</option>';
            foreach($cats as $c) echo '<option value="'.(int)$c['id'].'">'.e($c['name']).'</option>';
            echo '</select></label><label>Condition<select name="condition_label"><option value="condition_not_specified">Select condition</option><option value="new">New</option><option value="open_box">Open-box</option><option value="refurbished">Refurbished</option><option value="used">Used</option><option value="seller_verified">Seller-verified condition</option></select></label><label>Status<select name="status"><option value="draft">Draft</option><option value="published">Published</option></select></label><label>Product image<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label></div><label>Description<textarea name="description" rows="4"></textarea></label><button>Save product</button></form>';
            $rows=db()->query('SELECT p.id,p.name,p.sku,p.price,p.status,i.stock_qty FROM products p LEFT JOIN inventory i ON i.product_id=p.id ORDER BY p.id DESC LIMIT 100')->fetchAll();
            echo '<section class="section"><h2>Current products</h2><div class="table-wrap"><table><tr><th>ID</th><th>Name</th><th>SKU</th><th>Price</th><th>Stock</th><th>Status</th></tr>';
            foreach($rows as $r) echo '<tr><td>'.(int)$r['id'].'</td><td><b>'.e($r['name']).'</b></td><td>'.e($r['sku']).'</td><td>'.money($r['price']).'</td><td>'.(int)$r['stock_qty'].'</td><td>'.status_badge($r['status']).'</td></tr>';
            echo '</table></div></section>'; layout_footer();
        } elseif($sub==='categories') {
            if($method==='POST') { verify_csrf(); $name=trim((string)($_POST['name']??'')); if($name==='') { flash('error','Category name required.'); redirect('admin/categories'); } $slug=slugify($name); try { $st=db()->prepare('INSERT INTO categories(name,slug,description,parent_id,sort_order,is_active,created_at) VALUES(?,?,?,?,?,1,NOW())'); $st->execute([$name,$slug,trim((string)($_POST['description']??'')),((int)($_POST['parent_id']??0) ?: null),(int)($_POST['sort_order']??0)]); flash('success','Category created.'); } catch(Throwable $ex) { flash('error','Could not create category; check duplicate slug and parent.'); } redirect('admin/categories'); }
            layout_header('Admin categories'); page_heading('Categories','Create dynamic departments and subcategories.');
            echo '<form class="form-card narrow" method="post">'.csrf_field().'<label>Name<input name="name" required></label><label>Description<textarea name="description"></textarea></label><label>Parent category<select name="parent_id"><option value="0">Top-level</option>';
            foreach(get_categories(false) as $c) echo '<option value="'.(int)$c['id'].'">'.e($c['name']).'</option>';
            echo '</select></label><label>Sort order<input type="number" name="sort_order" value="0"></label><button>Create category</button></form><section class="section"><h2>Categories</h2><div class="table-wrap"><table><tr><th>Name</th><th>Slug</th><th>Status</th></tr>';
            foreach(get_categories(false) as $c) echo '<tr><td>'.e($c['name']).'</td><td>'.e($c['slug']).'</td><td>Active</td></tr>';
            echo '</table></div></section>'; layout_footer();
        } elseif($sub==='orders') {
            if($method==='POST') { verify_csrf(); $id=(int)($_POST['id']??0); $status=(string)($_POST['status']??''); $allowed=['pending_confirmation','confirmed','processing','packed','shipped','delivered','cancelled']; if(in_array($status,$allowed,true)) { $st=db()->prepare('UPDATE orders SET status=?,updated_at=NOW() WHERE id=?'); $st->execute([$status,$id]); flash('success','Order status updated.'); } redirect('admin/orders'); }
            layout_header('Admin orders'); page_heading('Orders','Review and update order processing status.');
            $rows=db()->query('SELECT o.*,u.name customer_name,u.email FROM orders o LEFT JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 200')->fetchAll();
            echo '<div class="table-wrap"><table><tr><th>Order</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Update</th></tr>';
            foreach($rows as $r) { echo '<tr><td><b>'.e($r['order_number']).'</b><br><small>'.e($r['created_at']).'</small></td><td>'.e($r['customer_name']??'Guest').'<br><small>'.e($r['email']??'').'</small></td><td><b>'.money($r['grand_total']).'</b></td><td>'.status_badge($r['payment_status']).'</td><td>'.status_badge($r['status']).'</td><td><form method="post" class="inline">'.csrf_field().'<input type="hidden" name="id" value="'.(int)$r['id'].'"><select name="status" aria-label="Status for '.e($r['order_number']).'">'; foreach(['pending_confirmation','confirmed','processing','packed','shipped','delivered','cancelled'] as $s) echo '<option '.($s===$r['status']?'selected':'').' value="'.e($s).'">'.e(ucwords(str_replace('_',' ',$s))).'</option>'; echo '</select><button>Save</button></form></td></tr>'; }
            echo '</table></div>'; layout_footer();
        } elseif($sub==='shipping') {
            if($method==='POST') { verify_csrf(); $id=(int)($_POST['order_id']??0); $courier=trim((string)($_POST['courier']??'')); $tracking=trim((string)($_POST['tracking_number']??'')); $trackUrl=trim((string)($_POST['tracking_url']??'')); $status=(string)($_POST['shipment_status']??'not_shipped'); $allowed=['not_shipped','packed','shipped','in_transit','delivered','failed','returned']; if($trackUrl!=='' && !filter_var($trackUrl,FILTER_VALIDATE_URL)) { flash('error','Tracking URL must be a valid URL.'); redirect('admin/shipping'); } if(in_array($status,$allowed,true)) { $st=db()->prepare('INSERT INTO shipments(order_id,courier_name,tracking_number,tracking_url,status,updated_at) VALUES(?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE courier_name=VALUES(courier_name),tracking_number=VALUES(tracking_number),tracking_url=VALUES(tracking_url),status=VALUES(status),updated_at=NOW()'); $st->execute([$id,$courier,$tracking,$trackUrl,$status]); $st=db()->prepare('UPDATE orders SET shipment_status=? WHERE id=?'); $st->execute([$status,$id]); flash('success','Manual shipment details saved.'); } redirect('admin/shipping'); }
            layout_header('Shipping settings'); page_heading('Shipping & delivery','Provider API is intentionally not configured.');
            echo '<div class="notice"><b>Delivery integration: Not configured</b><p>Choose a provider and obtain official API documentation and credentials before enabling automated shipping. Manual shipment tracking is available below.</p><p>Future adapter operations: serviceability, shipment creation/cancellation, tracking, labels and verified webhooks.</p></div>';
            $orders=db()->query("SELECT id,order_number,status FROM orders WHERE status NOT IN ('cancelled') ORDER BY id DESC LIMIT 100")->fetchAll();
            echo '<form class="form-card" method="post">'.csrf_field().'<h2>Manual shipment</h2><div class="form-grid"><label>Order<select name="order_id" required><option value="">Choose order</option>';
            foreach($orders as $o) echo '<option value="'.(int)$o['id'].'">'.e($o['order_number']).' — '.e($o['status']).'</option>';
            echo '</select></label><label>Courier name<input name="courier"></label><label>Tracking number<input name="tracking_number"></label><label>Tracking URL<input type="url" name="tracking_url"></label><label>Status<select name="shipment_status"><option value="not_shipped">Not shipped</option><option value="packed">Packed</option><option value="shipped">Shipped</option><option value="in_transit">In transit</option><option value="delivered">Delivered</option><option value="failed">Failed</option><option value="returned">Returned</option></select></label></div><button>Save shipment</button></form>'; layout_footer();
        } elseif($sub==='users') {
            if($method==='POST') {
                verify_csrf();
                $id=(int)($_POST['id']??0); $action=(string)($_POST['action']??'');
                $me=(int)current_user()['id'];
                if($id===$me) { flash('error','You cannot change your own account from this list.'); redirect('admin/users'); }
                $st=db()->prepare('SELECT id,role,status FROM users WHERE id=? LIMIT 1'); $st->execute([$id]); $target=$st->fetch();
                if(!$target) { flash('error','User not found.'); redirect('admin/users'); }
                if($action==='toggle_status') {
                    $new=$target['status']==='active'?'suspended':'active';
                    if($new==='suspended' && $target['role']==='admin') {
                        $c=(int)db()->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status='active'")->fetchColumn();
                        if($c<=1) { flash('error','At least one active admin must remain.'); redirect('admin/users'); }
                    }
                    $st=db()->prepare('UPDATE users SET status=?,updated_at=NOW() WHERE id=?'); $st->execute([$new,$id]);
                    flash('success','User '.$new.'.');
                } elseif($action==='toggle_role') {
                    $newRole=$target['role']==='admin'?'customer':'admin';
                    if($target['role']==='admin' && $target['status']==='active') {
                        $c=(int)db()->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status='active'")->fetchColumn();
                        if($c<=1) { flash('error','At least one active admin must remain.'); redirect('admin/users'); }
                    }
                    $st=db()->prepare('UPDATE users SET role=?,updated_at=NOW() WHERE id=?'); $st->execute([$newRole,$id]);
                    flash('success','Role updated to '.e($newRole).'.');
                } else { flash('error','Unknown action.'); }
                redirect('admin/users');
            }
            layout_header('Admin users'); page_heading('Users','Manage customer and staff accounts.');
            $rows=db()->query("SELECT u.id,u.name,u.email,u.role,u.status,u.created_at,(SELECT COUNT(*) FROM orders o WHERE o.user_id=u.id) orders FROM users u ORDER BY u.id DESC LIMIT 200")->fetchAll();
            echo '<div class="table-wrap"><table><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Orders</th><th>Joined</th><th>Actions</th></tr>';
            $me=(int)current_user()['id'];
            foreach($rows as $r) {
                echo '<tr><td>'.(int)$r['id'].'</td><td><b>'.e($r['name']).'</b></td><td>'.e($r['email']).'</td><td><span class="badge role-'.e($r['role']).'">'.e(ucfirst((string)$r['role'])).'</span></td><td>'.status_badge($r['status']).'</td><td>'.(int)$r['orders'].'</td><td><small>'.e($r['created_at']).'</small></td><td>';
                if((int)$r['id']===$me) echo '<span class="muted">You</span>';
                else {
                    echo '<form method="post" class="inline">'.csrf_field().'<input type="hidden" name="id" value="'.(int)$r['id'].'">';
                    echo '<button name="action" value="toggle_role" class="secondary">'.($r['role']==='admin'?'Make customer':'Make admin').'</button>';
                    echo '<button name="action" value="toggle_status" class="secondary">'.($r['status']==='active'?'Suspend':'Activate').'</button>';
                    echo '</form>';
                }
                echo '</td></tr>';
            }
            echo '</table></div>'; layout_footer();
        } elseif($sub==='settings') {
            $currencies=['INR','USD','EUR','GBP'];
            if($method==='POST') {
                verify_csrf();
                $storeName=trim((string)($_POST['store_name']??''));
                $currency=(string)($_POST['currency']??'INR');
                $heroT=trim((string)($_POST['hero_title']??''));
                $heroS=trim((string)($_POST['hero_subtitle']??''));
                $ann=trim((string)($_POST['announcement']??''));
                $currencies=['INR','USD','EUR','GBP'];
                if($storeName===''||mb_strlen($storeName)>120) { flash('error','Store name is required (max 120 characters).'); redirect('admin/settings'); }
                if(!in_array($currency,$currencies,true)) { flash('error','Unsupported currency.'); redirect('admin/settings'); }
                if(mb_strlen($heroT)>160||mb_strlen($heroS)>160||mb_strlen($ann)>200) { flash('error','One or more text fields exceed their limits (hero 160, banner 200 characters).'); redirect('admin/settings'); }
                set_setting('store_name',$storeName);
                set_setting('currency',$currency);
                set_setting('hero_title',$heroT);
                set_setting('hero_subtitle',$heroS);
                set_setting('announcement',$ann);
                flash('success','Settings saved. The storefront updates immediately.');
                redirect('admin/settings');
            }
            layout_header('Store settings'); page_heading('Site settings','Control the storefront from the panel.');
            $storeName=(string)setting('store_name',(string)cfg('app_name','Marketplace'));
            $currency=(string)setting('currency',(string)cfg('currency','INR'));
            $heroT=(string)setting('hero_title','Find your next favourite.');
            $heroS=(string)setting('hero_subtitle','Explore useful finds across fashion, electronics, home, and everyday essentials — with clear product details and transparent policies.');
            $ann=(string)setting('announcement','');
            echo '<form class="form-card" method="post">'.csrf_field().'<h2>Storefront</h2><div class="form-grid"><label>Store name<input name="store_name" required maxlength="120" value="'.e($storeName).'"></label><label>Currency<select name="currency">';
            foreach($currencies as $code) echo '<option '.($code===$currency?'selected':'').' value="'.e($code).'">'.e($code).' ('.e(currency_symbol($code)).')</option>';
            echo '</select></label></div><label>Hero title<input name="hero_title" maxlength="160" value="'.e($heroT).'"></label><label>Hero subtitle<textarea name="hero_subtitle" rows="2" maxlength="160">'.e($heroS).'</textarea></label><label>Announcement banner <small>(shown site-wide; leave empty to hide)</small><input name="announcement" maxlength="200" value="'.e($ann).'" placeholder="e.g. Free delivery over ₹999 this week"></label><button>Save settings</button></form>';
            layout_footer();
        } else { http_response_code(404); layout_header('Admin page not found'); page_heading('Admin page not found'); layout_footer(); }
    } elseif (in_array($path,['about','contact','shipping-policy','return-policy','privacy-policy','terms','deals','new-arrivals','best-sellers'],true)) {
        $titles=['about'=>'About us','contact'=>'Contact us','shipping-policy'=>'Shipping policy','return-policy'=>'Returns and refunds','privacy-policy'=>'Privacy policy','terms'=>'Terms and conditions','deals'=>'Deals','new-arrivals'=>'New arrivals','best-sellers'=>'Best sellers'];
        layout_header($titles[$path]); page_heading($titles[$path]);
        if(in_array($path,['deals','new-arrivals','best-sellers'],true)) { echo '<div class="product-grid">'; foreach(get_products(24) as $p) product_card($p); echo '</div>'; }
        else echo '<div class="panel"><p>This page must be reviewed and completed by the business owner before launch. Publish accurate business details, contact channels, delivery terms, return eligibility, warranty terms, privacy practices, and terms applicable to the store.</p></div>';
        layout_footer();
    } else {
        http_response_code(404); layout_header('Page not found'); page_heading('We could not find that page','The page may have moved or the address may be incorrect.'); echo '<a class="button" href="'.e(url('')).'">Back to home</a>'; layout_footer();
    }
} catch(Throwable $e) {
    error_log(date('c').' '.$e->getMessage().PHP_EOL, 3, APP_ROOT.'/storage/logs/app.log');
    http_response_code(500);
    if (cfg('debug',false)) echo '<pre>'.e($e->getMessage()).'</pre>';
    else echo '<!doctype html><html><body><h1>Something went wrong</h1><p>Please try again later.</p></body></html>';
}

