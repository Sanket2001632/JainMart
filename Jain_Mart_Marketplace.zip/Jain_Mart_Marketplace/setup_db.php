<?php
declare(strict_types=1);
$pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=jainmart','root','');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXECUTE);
$sql = file_get_contents('database/schema.sql');
$statements = explode(';', $sql);
foreach ($statements as $stmt) {
    $stmt = trim($stmt);
    if ($stmt !== '') {
        try {
            $pdo->exec($stmt);
            echo "OK\n";
        } catch (Exception $e) {
            echo "ERROR: " . $e->getMessage() . "\n";
        }
    }
}
echo "Done\n";