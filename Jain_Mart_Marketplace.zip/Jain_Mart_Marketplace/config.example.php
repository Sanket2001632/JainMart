<?php
declare(strict_types=1);

/*
 * Copy to config.php in the PRIVATE application directory.
 * Do not place real secrets in public_html or commit config.php.
 */
return [
    'app_name' => 'Marketplace',
    'base_url' => 'https://example.com',
    'app_key' => 'REPLACE_WITH_A_LONG_RANDOM_SECRET_AT_LEAST_32_CHARACTERS',
    'debug' => false,
    'db' => [
        'host' => 'localhost',
        'port' => 3306,
        'name' => 'YOUR_DATABASE_NAME',
        'user' => 'YOUR_DATABASE_USER',
        'pass' => 'YOUR_DATABASE_PASSWORD',
        'charset' => 'utf8mb4',
    ],
    'currency' => 'INR',
    'shipping' => [
        'provider' => '',
        'configured' => false,
    ],
];
