<?php
declare(strict_types=1);

return [
    'app_name' => 'Jain Mart',
    'base_url' => 'http://localhost/jainmart/public',
    'app_key' => 'tk0xc7sobgj6n93qp81rv5hfimezldwuya24',
    'debug' => false,
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'jainmart',
        'user' => 'jainmart',
        'pass' => 'pcwsumavhrqyn019igj7k2xotb4e',
        'charset' => 'utf8mb4',
    ],
    'currency' => 'INR',
    'shipping' => [
        'provider' => '',
        'configured' => false,
    ],
];

